/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import VISTA.Historial_Transacciones;

/**
 *
 * @author CASA
 */
public class Controlador_Historial {

    private Historial_Transacciones vistah;

    public Controlador_Historial(Historial_Transacciones vistah) {
        this.vistah = vistah;
        inicializar();
    }

    private void inicializar() {
        // Aquí puedes realizar tareas de inicialización si es necesario
        // También puedes agregar lógica adicional según tus necesidades
    }
}
