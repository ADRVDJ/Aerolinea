/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import VISTA.Principal;
import VISTA.Registroc;
import VISTA.Reserva_Hoteles;

/**
 *
 * @author CASA
 */
public class controlador_Reserva_hotel {

    private Reserva_Hoteles vista;

    public controlador_Reserva_hotel(Reserva_Hoteles vista) {
        this.vista = vista;
       // inicializar();
    }

}
